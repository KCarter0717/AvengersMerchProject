<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != "Client") {
setcookie("login", "", time());
redirect('login.php');
exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<style>
body {
  margin: 0;
}
body {
  width: 100vw;
  background-color: #f4f4f8;
  height: 0;

}
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 25%;
  background-color: #f1f1f1;
  position: fixed;
  overflow: auto;
}

li a {
  display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
}




input[type=text] {
 
  background-color: white;
  background-image: url('searchicon.png');
  background-position: 10px 10px; 
  background-repeat: no-repeat;
 
}





img.avatar {
  width: 60%;
  border-radius: 70%;
}




/* Remove extra left and right margins, due to padding */
.row {margin: 0 5px;}

/* Clear floats after the columns */


/* Responsive columns */


</style>
</head>
<body>

<ul>
<br><div style="text-align: center;"><img src="https://wallpapercave.com/wp/wp3104268.jpg" alt="Avatar" class="avatar"><br>
  <li><a style="font-size:2vw;" href="homepage2.php">Home</a></li> 
  <li><a style="font-size:2vw;" href="Account.php">Account</a></li> 
  <li><a style="font-size:2vw;" href="logout.php">Logout</a></li> 
</ul>

<div style="margin-left:25%;padding:1px 16px;height:0x;" >
    <h2 style="font-size:3vw;">Cart</h2>
  <br>
  </div> 
  
</body>
</html>
<?php
@ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3', 'lovei1_Project');

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }
$query = "select cart.clientid as clientid, cart.quantity as quantity, cart.price as price, products.name as productname from cart join products on cart.itemid = products.productid where clientid = ".$_COOKIE["clientid"]."";
$result = $db->query($query);
$tprice = 0;
$tquan = 0;
 $num_results = $result->num_rows;
 for ($i=0; $i <$num_results; $i++) {
     $row = $result->fetch_assoc();
     echo "<p><strong><center>".($i+1).". ";
     echo htmlspecialchars(stripslashes($row['productname']));
     echo "</strong><br />Quantity: ";
     echo stripslashes($row['quantity']);
     echo "<br />Price: ";
     echo stripslashes($row['price']);
     echo "<br />Subtotal: ";
     echo stripslashes($row['price'] * $row['quantity']);
     echo "</p></center>";
     $tprice = $tprice + ($row['price'] * $row['quantity']);
     $tquan = $tquan + $row['quantity'];
  }
  echo("<center>Total unique items: ".$num_results."");
  echo("<center>Total items: ".$tquan."");
  echo("<br />Subtotal before taxes: ".$tprice."");
  $tprice = $tprice * 1.07;
  $tprice = floor($tprice * 100) / 100;
  echo("<br />Subtotal after taxes: ".$tprice."</center>");
?>
<html>
    <form action="order.php" method="post">
    <select name="tprice">
      <option value=<?php echo $tprice; ?>> Total: <?php echo $tprice; ?>  
    </select>
    <select name="tquan">
      <option value=<?php echo $tquan; ?>> Total Items: <?php echo $tquan; ?>  
    </select>
    <br />
    <input type="submit" name="submit" value="Order">
  </form>
</html>