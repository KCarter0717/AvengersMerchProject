<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != "Client") {
setcookie("login", "", time());
redirect('login.php');
exit();
}
$searchtype=$_POST['searchtype'];
  $searchterm=trim($_POST['searchterm']);

  if (!$searchtype || !$searchterm) {
     echo 'You have not entered search details.  Please go back and try again.';
     exit;
  }

  if (!get_magic_quotes_gpc()){
    $searchtype = addslashes($searchtype);
    $searchterm = addslashes($searchterm);
  }

  @ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3','lovei1_Project');

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }
  
   $query = "select * from products where name like '%".$searchterm."%'";
  $result = $db->query($query);
  
  $num_results = $result->num_rows;

  echo "<p>Number of products found: ".$num_results."</p>";

  for ($i=0; $i <$num_results; $i++) {
     $row = $result->fetch_assoc();
     echo "<p><strong>".($i+1).". Product Name: ";
     echo htmlspecialchars(stripslashes($row['name']));
     echo "<br />Poduct Description: ";
     echo stripslashes($row['description']);
     echo "<br />Quantity in Stock: ";
     echo stripslashes($row['quantity']);
     echo "<br />Product ID: ";
     echo stripslashes($row['productid']);
     echo "</p>";
  }

  $result->free();
  $db->close();

?>

<html>
    
     <button onclick="window.location.href = 'homepage2.php';">BACK HOME</button>
</html>