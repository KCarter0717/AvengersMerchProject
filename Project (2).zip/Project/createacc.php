<?php
function redirect($url) {
header("Location: ".$url."");
}
@ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3', 'lovei1_Project');

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }
  $username=$_POST['username'];
   $email=$_POST['email'];
    $fname=$_POST['fname'];
     $minitial=$_POST['minitial'];
      $lname=$_POST['lname'];
       $password=$_POST['psw'];
 $query = "insert into client(fname, lname, minitial, email, username, password) values ('".$fname."', '".$lname."', '".$minitial."', '".$email."', '".$username."', md5('".$password."'))";
  $result = $db->query($query);
  
  if(!$result) {
      echo ("Account not created.");
      exit();
  } else redirect('login.php');
?>