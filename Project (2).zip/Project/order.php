<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != "Client") {
setcookie("login", "", time());
redirect('login.php');
exit();
}
?>
<?php
@ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3', 'lovei1_Project');

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }
   date_default_timezone_set('America/New_York');
    $DateAndTime = date('m-d-Y h:i:s a', time());  
    $numitems=$_POST['tquan'];
    $subtotal=$_POST['tprice'];
    $query = "insert into orders(clientnum, subtotal, numitems, date) values (".$_COOKIE["clientid"].", ".$subtotal.", ".$numitems.", '".$DateAndTime."')";
    $result = $db->query($query);
    if (!$result) {
        echo "Could not create order. Try again.";
        exit();
    } else {
        $query = "select orderid from orders where date = '".$DateAndTime."'";
    $result = $db->query($query);
    $orderid = array_values(mysqli_fetch_assoc($result))[0];
    $query = "select itemid, quantity, price from cart where clientid = ".$_COOKIE["clientid"]."";
    $result = $db->query($query);
    $num_results = $result->num_rows;
 for ($i=0; $i <$num_results; $i++) {
     $row = $result->fetch_assoc();
    $query = "insert into orderlist(ordernum, itemnum, itemprice, quantityordered) values (".$orderid.", ".$row['itemid'].", ".$row['price'].", ".$row['quantity'].")";
    $db->query($query);
  }
  $query = "delete from cart where 1";
  $db->query($query);
  echo ("Succesfully Ordered!");
    }
?>
<html>
    
    <button onclick="window.location.href = 'homepage2.php';">Back Home</button>
</html>