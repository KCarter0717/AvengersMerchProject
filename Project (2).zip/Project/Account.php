<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != ("Client" || "HR")) {
setcookie("login", "", time());
redirect('login.php');
exit();
}
?>
<!DOCTYPE html>
<html>
<head>
<style>
body {
  margin: 0;
}
body {
  width: 100vw;
  background-color: #f4f4f8;
  height: 0;

}
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 25%;
  background-color: #f1f1f1;
  position: fixed;
  overflow: auto;
}

li a {
  display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
}




input[type=text] {
 
  background-color: white;
  background-image: url('searchicon.png');
  background-position: 10px 10px; 
  background-repeat: no-repeat;
 
}





img.avatar {
  width: 60%;
  border-radius: 70%;
}




/* Remove extra left and right margins, due to padding */
.row {margin: 0 5px;}

/* Clear floats after the columns */


/* Responsive columns */


</style>
</head>
<body>

<ul>
<br><div style="text-align: center;"><img src="https://wallpapercave.com/wp/wp3104268.jpg" alt="Avatar" class="avatar"><br>
  <li><a style="font-size:2vw;" href="logout.php">Logout</a></li> 
</ul>

<div style="margin-left:25%;padding:1px 16px;height:0x;" >
    <h2 style="font-size:3vw;">Account History for ID: <?php echo $_COOKIE["clientid"]?></h2>
  <br>
  </div> 
  
</body>
</html>

<?php
@ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3', 'lovei1_Project');

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
 }
$query = "select orderid, date, subtotal, numitems from orders where clientnum = ".$_COOKIE["clientid"]."";
$result = $db->query($query);
 $num_results = $result->num_rows;
 for ($i=0; $i <$num_results; $i++) {
     $row = $result->fetch_assoc();
     $orderid = $row['orderid'];
     echo "<p><strong><center>".$orderid.". ";
     echo htmlspecialchars(stripslashes($row['date']));
      echo "</strong><br />Subtotal: ";
     echo stripslashes($row['subtotal']);
     echo "</strong><br />Number of Items: ";
     echo stripslashes($row['numitems']);
    $query2 = "select products.name as itemname, orderlist.itemprice as price, orderlist.quantityordered as quantity from orderlist join products on 
        orderlist.itemnum = products.productid where ordernum = ".$orderid."";
     $result2 = $db->query($query2);
     $num_results2 = $result2->num_rows;
     for ($j=0; $j <$num_results2; $j++) {
        $row = $result2->fetch_assoc();
        echo "<br />-";
        echo htmlspecialchars(stripslashes($row['itemname']));
        echo "<br />Quantity: ";
        echo stripslashes($row['quantity']);
        echo "<br />Price: ";
        echo stripslashes($row['price']);
     }
     
 }
?>