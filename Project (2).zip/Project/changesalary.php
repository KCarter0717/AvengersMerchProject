<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != "Manager") {
setcookie("login", "", time());
redirect('login.php');
exit();
}?>
<html>
<head>
  <title>Change Salary Results</title>
</head>
<meta http-equiv="refresh" content="1; url = http://cyan.csam.montclair.edu/~lovei1/prokect/homepagemanager.html" />
<body>
<h1>Change Salary Results</h1>
<?php
  // create short variable names
  $empids=$_POST['empids'];
  $salary=trim($_POST['salary']);
  
 
  if (!get_magic_quotes_gpc()){
    $empids = addslashes($empids);
    $salary = addslashes($salary);
  }
 
    @ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3', 'lovei1_Project');

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }
  
 
 $query = "update employee set salary = ".$salary." where employeeid = '".$empids."'";
  $result = $db->query($query);
  
    if (!$result) {
     echo 'Ran into error, try again.';
     exit;
  } else echo 'Salary changed.';

  $result->free();
  $db->close();
  

?>



</body>
</html>
