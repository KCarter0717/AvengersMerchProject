<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != "HR") {
setcookie("login", "", time());
redirect('emplogin.php');
exit();
}?>
<html>
<head>
  <title>Delete Account Results</title>
</head>
<meta http-equiv="refresh" content="1; url = http://cyan.csam.montclair.edu/~lovei1/prokect/homepagecustomerrep.html" />
<body>
<h1>Delete Account Results</h1>
<?php
  // create short variable names
  $searchtype=$_POST['searchtype'];
  $searchterm=trim($_POST['searchterm']);
 
  if (!get_magic_quotes_gpc()){
    $searchtype = addslashes($searchtype);
    $searchterm = addslashes($searchterm);
  }
    $pointsamount = 5;
 
    @ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3', 'lovei1_Project');

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }
  
   $query = "delete from client where clientid = '".$searchterm."'";
  $result = $db->query($query);
 
  $result->free();
  $db->close();
  

?>



</body>
</html>
