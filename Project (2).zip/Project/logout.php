<?php
function redirect($url) {
header("Location: ".$url."");
}
setcookie('login', null, -1, '/'); 
setcookie('clientid', null, -1, '/'); 
redirect('login.php');
        exit();
?>