<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != "HR") {
setcookie("login", "", time());
redirect('login.php');
exit();
}
  $clientid=$_POST['id'];
setcookie("clientid", $clientid, time()+900);
redirect("Account.php");
?>