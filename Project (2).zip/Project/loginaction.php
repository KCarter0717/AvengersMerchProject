<?php
function redirect($url) {
header("Location: ".$url."");
}
?>
<?php
  // create short variable names
  $uname=$_POST['uname'];
  $password=$_POST['psw'];
  if (!$uname || !$password) {
     echo 'You have not entered search details.  Please go back and try again.';
     exit;
  }

  if (!get_magic_quotes_gpc()){
    $searchtype = addslashes($searchtype);
    $searchterm = addslashes($searchterm);
  }

  @ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3', 'lovei1_Project');

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }

 
    #$query = $db->prepare("select clientid from client where username = ? and password = ?");
    #$query -> bind_param("ss", $uname, $password);
    #echo $query;
    $query = "select clientid from client where username = '".$uname."' and password = md5('".$password."')";
    $result = $db->query($query);
    $clientid = array_values(mysqli_fetch_assoc($result))[0];
    if($clientid > 0) {
        #create session cookie
        #redirect to homepage
        setcookie("clientid", $clientid, time() + 900, "/");
        setcookie("login", "Client", time() + 900, "/");
       redirect('homepage2.php');
       exit();
    } else {
        #clear session cookie
        #redirect back to login
   
    setcookie("login", "", time());
     redirect('login.php');
        exit();
    }

  $result->free();
  $db->close();

?>

