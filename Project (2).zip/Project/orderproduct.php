<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != "Stock") {
setcookie("login", "", time());
redirect('login.php');
exit();
}

 $productid=$_POST['productid'];
  $quantity=$_POST['quantity'];
 
  if (!$productid || !$quantity) {
     echo 'You have not entered search details.  Please go back and try again.';
     exit;
  }

  @ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3', 'lovei1_Project');

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }
  
  $query = "update products set quantity = quantity + ".$quantity." where productid = ".$productid."";
  $result = $db->query($query);
  if (!$result) {
      echo("Product not ordered.");
      exit();
  } else redirect("homepagestock.php");
?>