<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
form {border: 3px solid #f1f1f1;}

input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}

button {
  background-color: #04AA6D;
  color: white;
  padding: 10px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #f44336;
}
.adminbtn {
  width: auto;
  padding: 10px 18px;
  background-color:  #2020ce;
  margin-left: 10px 15px;
}
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

img.avatar {
  width: 40%;
  border-radius: 50%;
}

.container {
  padding: 16px;
}

span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>
<body>

<h2>Customer Registration</h2>

<form action="createacc.php" method="post">
  <div class="imgcontainer">
    <img src="https://wallpapercave.com/wp/wp3104268.jpg" alt="Avatar" class="avatar" style= "text-align: left;">
  </div>

  <div class="container">
    <label for="username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" minlength="5" required>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>
    
    <label for="fname"><b>First Name</b></label>
    <input type="text" placeholder="Enter First Name" name="fname" required>
    
    <label for="minitial"><b>Middle Initial</b></label>
    <input type="text" placeholder="Enter Middle Initial" name="minitial">
    
    <label for="lname"><b>Last Name</b></label>
    <input type="text" placeholder="Enter Last Name" name="lname" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="psw" minlength="8" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required>

    <!--<label for="address"><b>Address</b></label>
    <input type="text" placeholder="Enter Address" name="address" minlength="6" required>

    <label for="city"><b>City</b></label>
    <input type="text" placeholder="Enter City" name="city" minlength="3" required>

    <label for="state"><b>State</b></label>
    <input type="text" placeholder="Enter State" name="state" minlength="5" required>

    <label for="zip"><b>Zip-Code</b></label>
    <input type="text" placeholder="Enter zip code" name="zip" minlength="5" required>

    <label for="phone"><b>Phone Number</b></label>
    <input type="text" placeholder="Enter phone number" name="phone" minlength="10" required>-->

    <button type="submit">Submit</button>
    <div>
    
    <button type="button" class="cancelbtn"><a href="login.php">Cancel</a></button >   
</div>
  </div> 

  <div class="container" style="background-color:#f1f1f1">
  <span class="psw"><a href="login.php">Already have an account? Login here</a></span>
  </div>

</form>

</body>
</html>
