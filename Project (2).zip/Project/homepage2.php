<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != "Client") {
setcookie("login", "", time());
redirect('login.php');
exit();
}
?><!DOCTYPE html>
<html>
<head>
<style>
body {
  margin: 0;
}
body {
  width: 100vw;
  height: 100vh;
  background-color: #f4f4f8;
  background-size: cover;
}
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 25%;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

li a {
  display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
}

li a.active {
  background-color: #04AA6D;
  color: white;
}

li a:hover:not(.active) {
  background-color: #555;
  color: white;
}
input[type=text] {
  width: 130px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
  background-image: url('searchicon.png');
  background-position: 10px 10px; 
  background-repeat: no-repeat;
  padding: 12px 20px 12px 40px;
  -webkit-transition: width 0.4s ease-in-out;
  transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
  width: 100%;
}
div.gallery {
  margin: 13px;
  border: 1px solid #ccc;
  float: left;
  width: 180px;
}

div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 100%;
  height: auto;
}
img.avatar {
  width: 60%;
  border-radius: 70%;
}

div.desc {
  padding: 15px;
  text-align: center;
}
</style>
</head>
<body>

<ul>
<br><div style="text-align: center;"><img src="https://wallpapercave.com/wp/wp3104268.jpg" alt="Avatar" class="avatar"><br>
  <li><a style="font-size:2vw;" href="Cart.php">Cart</a></li> 
  <li><a style="font-size:2vw;" href="Account.php">Account</a></li> 
  <li><a style="font-size:2vw;" href="logout.php">Logout</a></li> 
</ul>

<div style="margin-left:25%;padding:1px 16px;height:350px;">
    <h2 style="font-size:3vw;">Avengers Outdoor Merchandise</h2>
  <br>
      <div class="gallery">
        <a target="_blank" href="BagsData.php">
          <img src="https://wallpapercave.com/wp/wp3104268.jpg"  alt="Clothes" width="1000" height="600">
        </a>
        <div class="desc">Bags </div>
      </div>

      <div class="gallery">
        <a target="_blank" href="Coolers.php">
          <img src="https://wallpapercave.com/wp/wp3104268.jpg" alt="Forest" width="800" height="600">
        </a>
        <div class="desc">Coolers</div>
      </div>
      
      <div class="gallery">
        <a target="_blank" href="Towels.php">
          <img src="https://wallpapercave.com/wp/wp3104268.jpg" alt="Northern Lights" width="800" height="600">
        </a>
        <div class="desc">Towels/Rags</div>
      </div>
      
      <div class="gallery">
        <a target="_blank" href="Sports.php">
          <img src="https://wallpapercave.com/wp/wp3104268.jpg" alt="Mountains" width="800" height="600">
        </a>
        <div class="desc">Sports</div>
      </div>

      <div class="gallery">
        <a target="_blank" href="Chairs.php">
          <img src="https://wallpapercave.com/wp/wp3104268.jpg" alt="Mountains" width="800" height="600">
        </a>
        <div class="desc">Chairs</div>
      </div>
</div>
<br />
 <form action="search.php" method="post">
    <center>Searching:<br />
    <select name="searchtype">
      <option value="name">Product Name
    </select>
    <br />
    Enter Search Term:<br />
    <input name="searchterm" type="text" size="100">
    <br />
    <input type="submit" name="submit" value="Search"></center>
  </form>

</body>
</html>