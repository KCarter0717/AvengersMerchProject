<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != "Stock") {
setcookie("login", "", time());
redirect('login.php');
exit();
}
@ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3', 'lovei1_Project');

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }
 $query = "select quantity from products where productid = 15";
    $result = $db->query($query);
    $lokiquant = array_values(mysqli_fetch_assoc($result))[0];
$query = "select price from products where productid = 15";
    $result = $db->query($query);
    $lokiprice = array_values(mysqli_fetch_assoc($result))[0];
?>
<!DOCTYPE html>
<html>
<head>
<style>
body {
  margin: 0;
}
body {
  width: 100vw;
  height: 100vh;
  background-color: #f4f4f8;
  background-size: cover;
}
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  width: 25%;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

li a {
  display: block;
  color: #000;
  padding: 8px 16px;
  text-decoration: none;
}

li a.active {
  background-color: #04AA6D;
  color: white;
}

li a:hover:not(.active) {
  background-color: #555;
  color: white;
}
input[type=text] {
  width: 130px;
  box-sizing: border-box;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-size: 16px;
  background-color: white;
  background-image: url('searchicon.png');
  background-position: 10px 10px; 
  background-repeat: no-repeat;
  padding: 12px 20px 12px 40px;
  -webkit-transition: width 0.4s ease-in-out;
  transition: width 0.4s ease-in-out;
}

input[type=text]:focus {
  width: 100%;
}
div.gallery {
  margin: 13px;
  border: 1px solid #ccc;
  float: left;
  width: 300px;
  height: 500px;
  
}


div.gallery:hover {
  border: 1px solid #777;
}

div.gallery img {
  width: 90%;
  height: auto;
}
img.avatar {
  width: 60%;
  border-radius: 70%;
}

div.desc {
  padding: 8px;
  text-align: center;
}
.column {
  float: left;
  width: 100%;
  padding: 0 10px;
}

/* Remove extra left and right margins, due to padding */
.row {margin: 0 5px;}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive columns */
@media screen and (max-width: 600px) {
  .column {
    width: 100%;
    display: block;
    margin-bottom: 4px;
  }
}

</style>
</head>
<body>

<ul>
<br><div style="text-align: center;"><img src="https://wallpapercave.com/wp/wp3104268.jpg" alt="Avatar" class="avatar"><br>
  <li><a style="font-size:2vw;" href="homepagestock.php">Home</a></li> 
  <li><a style="font-size:2vw;" href="logout.php">Logout</a></li> 
</ul>

<div style="margin-left:25%;padding:1px 16px;height:1000px;" >
  <h2 style="font-size:3vw;">Towels/Rags</h2>
<br>
    <div class="gallery">
      <div class="column">
      <div class="row">
      <a target="_blank" href="BlackPantherSportCoolingTowelProduct.jpg">
        <img src="BlackPantherSportCoolingTowelProduct.jpg" alt="Captain America DrawString" width="180" height="180">
      </a>
      <div class="desc"><strong>Black Panther Sport Cooling Towel</strong></div>
      <div class="desc">$8.99</div>
      <form action="/action_page.php">
        <label for="quantity"><center>Quantity:</label>
        <input type="number" id="quantity" name="quantity" min="1" max="25">
        <input type="submit"></center>
      </form>
      </div>
      </div>
    </div>
  
    <div class="gallery" >
      <div class="column">
      <div class="row">
      <a target="_blank" href="SpidermanSportCoolingTowelProduct.jpg">
        <img src="SpidermanSportCoolingTowelProduct.jpg" alt="Dr Strange Drawstring Bag" width="180" height="180">
      </a>
      <div class="desc"><strong>Spiderman Sport Cooling Towel</strong></div>
      <div class="desc">$8.99</div>
      <form action="/action_page.php">
        <label for="quantity"><center>Quantity:</label>
        <input type="number" id="quantity" name="quantity" min="1" max="25">
        <input type="submit"></center>
      </form>
  </div>
</div>
    </div>

    <div class="gallery" >
      <div class="column">
      <div class="row">
      <a target="_blank" href="LokiSpiritRallyTowelProduct.jpg">
        <img src="LokiSpiritRallyTowelProduct.jpg" alt="Thor Ogio Chill Lunch Bag" width="180" height="180">
      </a>
      <div class="desc"><strong>Loki Spirit Rally Towel</strong></div>
      <div class="desc"><?php echo "$".$lokiprice.""?></div>
          <label><center>QuantityIn Stock: <?php echo $lokiquant; ?></label>
      <form action="orderproduct.php" method="post">
    <select name="productid">
      <option value="15">Id: 15
    </select>
    <br />
    Enter Quantity to purchase<br />
    <input name="quantity" type="number" id="quantity" min="0">
    <br />
    <input type="submit" name="submit" value="Order">
  </form>
  </div>
</div>
    </div>

<div class="gallery" >
  <div class="column">
  <div class="row">
  <a target="_blank" href="BlackWidowSpiritRallyTowelProduct.jpg">
    <img src="BlackWidowSpiritRallyTowelProduct.jpg" width="180" height="180">
  </a>
  <div class="desc"><strong>Black Widow Spirit Rally Towel</strong></div>
  <div class="desc">$12.99</div>
  <form action="/action_page.php">
    <label for="quantity"><center>Quantity:</label>
    <input type="number" id="quantity" name="quantity" min="1" max="25">
    <input type="submit"></center>
  </form>
</div>
</div>
</div>

    <div class="gallery" >
      <div class="column">
      <div class="row">
      <a target="_blank" href="RocketRaccoonBeachTowelProduct.jpg">
        <img src="RocketRaccoonBeachTowelProduct.jpg" alt="Spiderman Small Canvas Pencil Case" width="180" height="180">
      </a>
      <div class="desc"><strong>Rocket Racoon Lightweight Embroidered Beach Towel</strong></div>
      <div class="desc">$4.99</div>
      <form action="/action_page.php">
        <label for="quantity"><center>Quantity:</label>
        <input type="number" id="quantity" name="quantity" min="1" max="25">
        <input type="submit"></center>
      </form>
  </div>
</div>
    </div>
  
    <div class="gallery" >
      <div class="column">
      <div class="row">
      <a target="_blank" href="GrootBeachTowelProduct.jpg">
        <img src="GrootBeachTowelProduct.jpg" alt="Scarlet Small Canvas Pencil Case" width="180" height="180">
      </a>
      <div class="desc"><strong>Groot Lightweight Embroidered Beach Towel</strong></div>
      <div class="desc">$4.99</div>
      <form action="/action_page.php">
        <label for="quantity"><center>Quantity:</label>
        <input type="number" id="quantity" name="quantity" min="1" max="25">
        <input type="submit"></center>
      </form>
  </div>
</div>
    </div>


    
  


</div>



      
    


</div>

</body>
</html>