<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != "Manager") {
setcookie("login", "", time());
redirect('login.php');
exit();
}?>
<html>
<head>
  <title>Employee Entry Results</title>
</head>
<body>
<h1>Employee Entry Results</h1>
<?php
  // create short variable names
  $empida=$_POST['empida'];
  $fname=$_POST['fname'];
  $lname=$_POST['lname'];
  $minitial=$_POST['minitial'];
  $salary=$_POST['salary'];
  $password=$_POST['password'];
  $managerid=$_POST['managerid'];
  $emptype=$_POST['emptype'];

  if (!$empida || !$fname || !$lname || !$salary || !$password || !$emptype) {
     echo "You have not entered all the required details.<br />"
          ."Please go back and try again.";
     exit;
  }
  if (!$minitial) $minitial = null;
  if (!$managerid) $managerid = null;

  if (!get_magic_quotes_gpc()) {
    $empida=addslashes($empida);
  $fname=addslashes($fname);
  $lname=addslashes($lname);
  $minitial=addslashes($minitial);
  $salary= intval($salary);
  $password=addslashes($password);
  $managerid=addslashes($managerid);
  $emptype=addslashes($emptype);
  }

  @ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3', 'lovei1_Project');

  if (mysqli_connect_errno()) {
     echo "Error: Could not connect to database.  Please try again later.";
     exit;
  }
  

  $query = "insert into employee values
            ('".$empida."', '".$fname."', '".$lname."', '".$minitial."', '".$salary."', '".$password."', '".$managerid."', '".$emptype."')";

 $result = $db->query($query);

  if ($result) {
    echo  $db->affected_rows." employee inserted into database.";
  } else {
  	  echo "An error has occurred.  The employee was not added.";
  }

  $db->close();
?>
</body>
</html>
