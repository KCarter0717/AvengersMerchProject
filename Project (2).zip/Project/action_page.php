<?php
function redirect($url) {
header("Location: ".$url."");
}
if ($_COOKIE["login"] != "Client") {
setcookie("login", "", time());
redirect('login.php');
exit();
}
?>
<?php
  $quantity=$_POST['quantity'];
  $productid=trim($_POST['productid']);
  $clientid = $_COOKIE["clientid"];
 
  if (!get_magic_quotes_gpc()){
    $quantity = addslashes($quantity);
    $productid = addslashes($productid);
    $clientid = addslashes($clientid);
  }
 
    @ $db = new mysqli('localhost', 'lovei1_ianhate', 'tfihp2371#3', 'lovei1_Project');

  if (mysqli_connect_errno()) {
     echo 'Error: Could not connect to database.  Please try again later.';
     exit;
  }
$query = "select price from products where productid = ".$productid."";
$result = $db->query($query);
$price = array_values(mysqli_fetch_assoc($result))[0];
 $query = "insert into cart(clientid, itemid, quantity, price) values(".$clientid.",".$productid.",".$quantity.", ".$price.")";
 $result = $db->query($query);
 if(!result) {
     echo ("Item was not added, try again.");
     exit();
 } else {
     echo ("Item was added to cart.");
     $query = "update products set quantity = quantity - ".$quantity." where productid = '".$productid."'";
     $result = $db->query($query);
 }
?>
<html>
    
    <button onclick="window.location.href = 'homepage2.php';">Back Home</button>
</html>